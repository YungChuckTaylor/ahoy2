/* Shared chrome, helpers, icons */
(function () {
  const ICONS = {
    anchor: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v3M12 21V10M8 7a4 4 0 1 0 8 0"/><path d="M5 12H3a9 9 0 0 0 18 0h-2M5 12c2 3 4.5 4 7 4s5-1 7-4"/></svg>',
    lock: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>',
  };

  function money(n, ccy) {
    const v = Number(n) || 0;
    return new Intl.NumberFormat("en-US", { style: "currency", currency: ccy || "USD", maximumFractionDigits: 0 }).format(v);
  }
  function money2(n) {
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(Number(n) || 0);
  }
  function country(id) {
    return (window.AHOY && AHOY.countries().find(c => c.id === id)) || { name: id, flag: "", city: "" };
  }
  function category(id) {
    return (window.AHOY && AHOY.categories().find(c => c.id === id)) || { name: id };
  }
  function pct(raised, goal) {
    if (!goal) return 0;
    return Math.min(100, Math.round((raised / goal) * 1000) / 10);
  }
  function qs(k) {
    return new URLSearchParams(location.search).get(k);
  }
  function formatDate(iso) {
    if (!iso) return "";
    const d = new Date(iso + (iso.length === 10 ? "T00:00:00" : ""));
    return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
  }

  function header(active) {
    return `
    <header class="site-header">
      <div class="wrap">
        <a class="brand" href="index.html">
          <img src="assets/logo.png" alt="AHOY — Association of Humble and Obedient Youths">
        </a>
        <button class="burger" aria-label="Open menu" id="burger"><span></span><span></span><span></span></button>
        <nav class="nav" id="nav">
          <a href="index.html" class="${active==="home"?"active":""}">Home</a>
          <a href="repository.html" class="${active==="archive"?"active":""}">Archive</a>
          <a href="transparency.html" class="${active==="money"?"active":""}">Where money goes</a>
          <a href="campaigns.html" class="${active==="give"?"active":""}">Campaigns</a>
          <a href="about.html" class="${active==="about"?"active":""}">About</a>
          <a href="contact.html" class="nav-plain ${active==="contact"?"active":""}">Contact</a>
          <a class="btn btn-gold btn-sm nav-cta" href="campaigns.html">Give to a campaign</a>
          <a href="admin.html" class="nav-admin">${ICONS.lock} Admin</a>
        </nav>
      </div>
    </header>`;
  }

  function footer() {
    return `
    <footer class="site-footer">
      <div class="wrap">
        <div class="foot-grid">
          <div>
            <a class="brand" href="index.html" style="margin-bottom:14px">
              <img src="assets/logo.png" alt="AHOY" style="height:40px;width:auto">
              <span class="word"><span>Est. 2018 · Four countries</span></span>
            </a>
            <p style="max-width:36ch;font-size:.9rem">The Association of Humble and Obedient Youths steers young people toward work, duty and quiet leadership. We publish what we do, and where the money goes.</p>
          </div>
          <div>
            <h4>Navigate</h4>
            <a href="repository.html">Verification archive</a>
            <a href="transparency.html">Financial dashboard</a>
            <a href="campaigns.html">Micro-fundraising</a>
            <a href="about.html">Mission &amp; chapters</a>
          </div>
          <div>
            <h4>Chapters</h4>
            <a href="repository.html?country=nigeria">Nigeria — Lagos, Kano</a>
            <a href="repository.html?country=egypt">Egypt — Cairo</a>
            <a href="repository.html?country=canada">Canada — Toronto</a>
            <a href="repository.html?country=uk">United Kingdom — London</a>
          </div>
          <div>
            <h4>Stewardship</h4>
            <a href="transparency.html#reports">Annual reports</a>
            <a href="transparency.html#reports">Audited statements</a>
            <a href="admin.html">Steward login</a>
            <a href="contact.html">Write to us</a>
          </div>
        </div>
        <div class="legal">
          <span>© ${new Date().getFullYear()} Association of Humble and Obedient Youths. A youth fellowship, not a spectacle.</span>
          <span>Demo site — payments are simulated and no real charges are taken.</span>
        </div>
      </div>
    </footer>`;
  }

  function mount() {
    const active = document.body.dataset.page || "";
    const h = document.getElementById("site-header");
    const f = document.getElementById("site-footer");
    if (h) h.outerHTML = header(active);
    if (f) f.outerHTML = footer();
    const burger = document.getElementById("burger");
    const nav = document.getElementById("nav");
    if (burger && nav) burger.addEventListener("click", () => nav.classList.toggle("open"));
  }

  function toast(msg) {
    let el = document.querySelector(".ok-toast");
    if (!el) {
      el = document.createElement("div");
      el.className = "ok-toast";
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.style.display = "block";
    clearTimeout(el._t);
    el._t = setTimeout(() => { el.style.display = "none"; }, 2800);
  }

  function campaignCard(c) {
    const co = country(c.country);
    const p = pct(c.raised, c.goal);
    return `
      <article class="card">
        <a href="campaign.html?id=${encodeURIComponent(c.id)}">
          <div class="card-media">
            <img src="${c.image}" alt="">
            <span class="verified-seal">${co.flag} ${co.name}</span>
          </div>
          <div class="card-body">
            <div class="meta-row"><span class="pill pill-live">Live campaign</span></div>
            <h3>${c.title}</h3>
            <p>${c.blurb}</p>
            <div class="fund-meta"><b>${money(c.raised)}</b><span>of ${money(c.goal)}</span></div>
            <div class="progress"><span style="width:${p}%"></span></div>
            <div class="muted" style="font-size:.78rem;margin-top:6px">${p}% funded · ${c.unit.label}</div>
          </div>
        </a>
      </article>`;
  }

  function itemCard(it) {
    const co = country(it.country);
    const cat = category(it.category);
    return `
      <article class="card" data-open="${it.id}">
        <div class="card-media">
          <img src="${it.image}" alt="">
          ${it.verified ? `<span class="verified-seal">Verified · ${it.id}</span>` : ""}
        </div>
        <div class="card-body">
          <div class="meta-row">
            <span class="pill">${cat.name}</span>
            <span class="pill pill-gold">${co.flag} ${co.name}</span>
          </div>
          <h3>${it.title}</h3>
          <p>${it.summary}</p>
          <p class="muted" style="margin-top:10px;font-size:.78rem">${formatDate(it.date)}</p>
        </div>
      </article>`;
  }

  window.UI = { money, money2, country, category, pct, qs, formatDate, mount, toast, campaignCard, itemCard };
  document.addEventListener("DOMContentLoaded", mount);
})();
