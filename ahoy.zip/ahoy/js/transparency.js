document.addEventListener("DOMContentLoaded", () => {
  const state = AHOY.get();
  const years = Object.keys(state.finances.years).sort((a,b) => b-a);
  let year = years[0];
  let pie, bars, line;

  const yearEl = document.getElementById("years");
  yearEl.innerHTML = years.map(y => `<button class="chip ${y===year?"on":""}" data-y="${y}">${y}${y==="2025"?" YTD":""}</button>`).join("");
  yearEl.addEventListener("click", e => {
    const b = e.target.closest("[data-y]");
    if (!b) return;
    year = b.dataset.y;
    yearEl.querySelectorAll(".chip").forEach(x => x.classList.toggle("on", x === b));
    render();
  });

  function render() {
    const f = state.finances.years[year];
    const h = state.finances.headline;
    document.getElementById("stats").innerHTML = `
      <div class="stat"><div class="lab">Income</div><div class="num">${UI.money(f.income)}</div></div>
      <div class="stat"><div class="lab">Spend</div><div class="num">${UI.money(f.spend)}</div></div>
      <div class="stat"><div class="lab">Held in reserve</div><div class="num">${UI.money(f.reserve)}</div></div>
      <div class="stat"><div class="lab">Direct programmes</div><div class="num">${Math.round(f.programs/f.spend*100)}%</div></div>`;

    document.getElementById("legend").innerHTML = h.map(x => `
      <div class="legend-row">
        <span><i class="swatch" style="background:${x.color}"></i>${x.label}</span>
        <b>${x.pct}%</b>
      </div>
      <div class="muted" style="font-size:.78rem;margin:-4px 0 8px 18px">${x.note}</div>`).join("");

    const pieData = {
      labels: h.map(x => x.label),
      datasets: [{ data: h.map(x => x.pct), backgroundColor: h.map(x => x.color), borderWidth: 0, hoverOffset: 8 }]
    };
    const pieOpts = { cutout: "62%", plugins: { legend: { display: false } } };
    if (pie) { pie.data = pieData; pie.update(); }
    else pie = new Chart(document.getElementById("pie"), { type: "doughnut", data: pieData, options: pieOpts });

    const countries = AHOY.countries();
    const totalC = Object.values(f.countries).reduce((a,b)=>a+b,0);
    document.getElementById("countries").innerHTML = countries.map(c => {
      const amt = f.countries[c.id] || 0;
      const p = Math.round(amt / totalC * 100);
      return `<div class="hbar">
        <div class="top"><span>${c.flag} ${c.name}</span><b>${UI.money(amt)} · ${p}%</b></div>
        <div class="track"><span style="width:${p}%;background:${c.id==="nigeria"?"#c9a227":c.id==="egypt"?"#c41e3a":c.id==="canada"?"#1e4a73":"#2a6494"}"></span></div>
      </div>`;
    }).join("");

    const barData = {
      labels: f.programsBreak.map(x => x.label),
      datasets: [{ data: f.programsBreak.map(x => x.amount), backgroundColor: "#c9a227", borderRadius: 8, barThickness: 18 }]
    };
    const barOpts = {
      indexAxis: "y",
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => " " + UI.money(c.raw) } } },
      scales: { x: { ticks: { callback: v => "$" + (v/1000) + "k" }, grid: { color: "rgba(0,0,0,.05)" } }, y: { grid: { display: false } } }
    };
    if (bars) { bars.data = barData; bars.update(); }
    else bars = new Chart(document.getElementById("bars"), { type: "bar", data: barData, options: barOpts });

    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const lineData = {
      labels: months,
      datasets: [{
        data: f.months, fill: true, tension: 0.35,
        borderColor: "#1e4a73", backgroundColor: "rgba(30,74,115,.12)",
        pointBackgroundColor: "#c9a227", pointRadius: 4
      }]
    };
    const lineOpts = {
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => " $" + c.raw + "k" } } },
      scales: { y: { ticks: { callback: v => "$" + v + "k" }, grid: { color: "rgba(0,0,0,.05)" } }, x: { grid: { display: false } } }
    };
    if (line) { line.data = lineData; line.update(); }
    else line = new Chart(document.getElementById("line"), { type: "line", data: lineData, options: lineOpts });

    const opsMax = Math.max(...f.opsBreak.map(x => x.amount));
    document.getElementById("ops").innerHTML = f.opsBreak.map(x => `
      <div class="hbar">
        <div class="top"><span>${x.label}</span><b>${UI.money(x.amount)}</b></div>
        <div class="track"><span style="width:${Math.round(x.amount/opsMax*100)}%;background:#1e4a73"></span></div>
      </div>`).join("");
  }

  const reports = AHOY.get().reports.slice().sort((a,b) => b.year - a.year || a.title.localeCompare(b.title));
  document.getElementById("report-list").innerHTML = reports.map(r => `
    <div class="report-row">
      <div>
        <h4>${r.title}</h4>
        <p>${r.status} · ${r.pages} pages · published ${UI.formatDate(r.date)}</p>
      </div>
      <span class="pill">${r.type === "audit" ? "Audit" : r.type === "annual" ? "Annual" : "Brief"}</span>
      <a class="btn btn-navy btn-sm" href="${r.file}" target="_blank" rel="noopener">Open / print</a>
    </div>`).join("");

  render();
});
