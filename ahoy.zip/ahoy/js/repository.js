document.addEventListener("DOMContentLoaded", () => {
  const catsEl = document.getElementById("cats");
  const grid = document.getElementById("grid");
  const count = document.getElementById("count");
  const q = document.getElementById("q");
  const countrySel = document.getElementById("country");
  const sortSel = document.getElementById("sort");
  const modal = document.getElementById("modal");
  const modalInner = modal.querySelector(".modal");

  let category = "all";

  AHOY.countries().forEach(c => {
    const o = document.createElement("option");
    o.value = c.id; o.textContent = c.flag + " " + c.name;
    countrySel.appendChild(o);
  });

  const preCountry = UI.qs("country");
  if (preCountry) countrySel.value = preCountry;

  const chips = [{ id: "all", name: "All records" }, ...AHOY.categories()];
  catsEl.innerHTML = chips.map(c =>
    `<button class="chip ${c.id==="all"?"on":""}" data-cat="${c.id}">${c.name}</button>`
  ).join("");

  catsEl.addEventListener("click", e => {
    const b = e.target.closest("[data-cat]");
    if (!b) return;
    category = b.dataset.cat;
    catsEl.querySelectorAll(".chip").forEach(x => x.classList.toggle("on", x === b));
    draw();
  });

  q.addEventListener("input", draw);
  countrySel.addEventListener("change", draw);
  sortSel.addEventListener("change", draw);

  function draw() {
    let list = AHOY.items({ category, country: countrySel.value, q: q.value.trim() });
    if (sortSel.value === "old") list = list.slice().reverse();
    count.textContent = list.length + " record" + (list.length === 1 ? "" : "s") + " in view";
    if (!list.length) {
      grid.innerHTML = `<div class="archive-empty">Nothing in this slice of the archive. Try another country or category.</div>`;
      return;
    }
    grid.innerHTML = list.map(UI.itemCard).join("");
    grid.querySelectorAll("[data-open]").forEach(el => {
      el.style.cursor = "pointer";
      el.addEventListener("click", () => openItem(el.dataset.open));
    });
  }

  function openItem(id) {
    const it = AHOY.item(id);
    if (!it) return;
    const co = UI.country(it.country);
    const cat = UI.category(it.category);
    modalInner.innerHTML = `
      <div class="modal-hero">
        <img src="${it.image}" alt="">
        <button class="modal-close" id="mclose">←</button>
      </div>
      <div class="modal-pad">
        <div class="meta-row">
          <span class="pill">${cat.name}</span>
          <span class="pill pill-gold">${co.flag} ${co.name}</span>
          ${it.verified ? `<span class="pill pill-ok">Verified ${UI.formatDate(it.verifiedOn)}</span>` : `<span class="pill">Unverified</span>`}
        </div>
        <h2>${it.title}</h2>
        <p class="muted">${it.summary}</p>
        <p>${it.body}</p>
        ${videoBlock(it.video)}
        <div class="verify-box">
          <div><div class="lab">Archive ID</div><b>${it.id}</b></div>
          <div><div class="lab">Record date</div><b>${UI.formatDate(it.date)}</b></div>
          <div><div class="lab">Verified by</div><b>${it.verifier || "—"}</b></div>
          <div><div class="lab">Witnesses</div><b>${(it.witnesses||[]).join(" · ") || "—"}</b></div>
        </div>
        <h3>Underlying papers</h3>
        <ul>${(it.documents||[]).map(d => `<li>${d}</li>`).join("")}</ul>
        <p class="muted" style="font-size:.8rem">Verification means a steward who did not spend the money has seen the papers and the photographs. It is not a government certification.</p>
      </div>`;
    modal.classList.add("open");
    document.getElementById("mclose").onclick = close;
  }
  function videoBlock(video) {
    if (!video || !video.url) return "";
    if (video.type === "youtube") {
      const id = youTubeId(video.url);
      if (!id) return "";
      return `<div class="video-embed"><iframe src="https://www.youtube.com/embed/${id}" title="Archive video" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>`;
    }
    if (video.type === "file") {
      return `<div class="video-embed"><video controls src="${video.url}"></video></div>`;
    }
    return "";
  }
  function youTubeId(url) {
    const m = String(url).match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/);
    return m ? m[1] : null;
  }
  function close() { modal.classList.remove("open"); }
  modal.addEventListener("click", e => { if (e.target === modal) close(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape") close(); });

  draw();
  const pre = UI.qs("item");
  if (pre) openItem(pre);
});
