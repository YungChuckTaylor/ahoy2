/* AHOY seed data — used when localStorage is empty */
window.AHOY_SEED = {
  meta: {
    name: "Association of Humble and Obedient Youths",
    short: "AHOY",
    founded: 2018,
    tagline: "Steered by humility. Powered by service.",
    email: "hello@ahoyyouths.org",
    phone: "+234 201 700 1840",
    hq: "Lagos, Nigeria"
  },

  countries: [
    { id: "nigeria", name: "Nigeria", city: "Lagos · Kano · Abuja", flag: "🇳🇬", currency: "NGN", rate: 1550 },
    { id: "egypt", name: "Egypt", city: "Cairo · Alexandria", flag: "🇪🇬", currency: "EGP", rate: 49 },
    { id: "canada", name: "Canada", city: "Toronto · Vancouver", flag: "🇨🇦", currency: "CAD", rate: 1.36 },
    { id: "uk", name: "United Kingdom", city: "London · Manchester", flag: "🇬🇧", currency: "GBP", rate: 0.78 }
  ],

  categories: [
    { id: "projects", name: "Projects", icon: "anchor" },
    { id: "events", name: "Events", icon: "flag" },
    { id: "trainings", name: "Trainings", icon: "book" },
    { id: "campaigns", name: "Campaigns", icon: "megaphone" },
    { id: "field-visits", name: "Field visits", icon: "map" },
    { id: "reports", name: "Reports", icon: "file" },
    { id: "case-studies", name: "Case studies", icon: "search" },
    { id: "media", name: "Photos / videos", icon: "camera" },
    { id: "partnerships", name: "Partnerships", icon: "handshake" },
    { id: "publications", name: "Publications", icon: "journal" }
  ],

  items: [
    {
      id: "AHY-2019-NG-014",
      title: "Harbour Workshops — vocational starters, Agege",
      category: "projects",
      country: "nigeria",
      date: "2025-03-12",
      verified: true,
      verifiedOn: "2025-03-18",
      verifier: "Chapter Steward, Lagos",
      image: "assets/images/vocational-kits.jpg",
      summary: "Fifty starter kits issued to apprentices in carpentry, electrical fitting and tailoring across Agege and Alimosho.",
      body: "The Harbour Workshops programme places tools, safety gear and a 12-week coaching roster in the hands of youths who have already secured a master-craftsman placement. Each kit is tagged, photographed at handover, and followed for six months. In the 2025 cohort, 44 of 50 apprentices were still in placement at the 90-day check.",
      witnesses: ["Adaeze Okonkwo", "Ibrahim Sule"],
      documents: ["Handover register", "Kit inventory", "90-day attendance"]
    },
    {
      id: "AHY-2024-NG-088",
      title: "Girls STEM Lab, Yaba",
      category: "projects",
      country: "nigeria",
      date: "2024-11-02",
      verified: true,
      verifiedOn: "2024-11-09",
      verifier: "Programmes Desk",
      image: "assets/images/stem-lab.jpg",
      summary: "A Saturday laboratory for 36 girls aged 13–18 covering circuits, Python basics and repair culture.",
      body: "Hosted at a borrowed classroom in Yaba, the lab runs 24 Saturdays a year. Mentors are university students who themselves came through AHOY trainings. Families contribute nothing; transport stipends are paid in cash against a signed roll.",
      witnesses: ["Funmi Adewale", "Chioma Eze"],
      documents: ["Saturday roll", "Stipend ledger", "Curriculum v3"]
    },
    {
      id: "AHY-2025-EG-021",
      title: "Cairo Mentorship Circle — season five",
      category: "trainings",
      country: "egypt",
      date: "2025-02-08",
      verified: true,
      verifiedOn: "2025-02-14",
      verifier: "Cairo Chapter",
      image: "assets/images/cairo-mentorship.jpg",
      summary: "Eighteen young mentors and 54 mentees meeting fortnightly in Downtown Cairo.",
      body: "Circles are kept small on purpose. Each mentor commits to nine months. Topics rotate through work readiness, family duty, digital safety and public speaking. Tea is the only hospitality cost charged to the programme.",
      witnesses: ["Yasmin Farouk", "Omar Khalil"],
      documents: ["Circle covenant", "Attendance book"]
    },
    {
      id: "AHY-2024-CA-033",
      title: "Winter Skills Camp, Scarborough",
      category: "events",
      country: "canada",
      date: "2024-12-28",
      verified: true,
      verifiedOn: "2025-01-06",
      verifier: "Toronto Steward",
      image: "assets/images/toronto-camp.jpg",
      summary: "A four-day indoor camp teaching first aid, basic carpentry and civic letter-writing to 40 youths.",
      body: "Held between Christmas and New Year so school-age members could attend without missing class. Meals were cooked on-site by volunteer parents. AHOY covered hall hire, materials and two Red Cross instructors.",
      witnesses: ["Priya Nandakumar", "James Okello"],
      documents: ["Hall invoice", "Instructor contracts", "Consent forms"]
    },
    {
      id: "AHY-2025-UK-007",
      title: "Apprenticeship stipends — East London",
      category: "projects",
      country: "uk",
      date: "2025-01-20",
      verified: true,
      verifiedOn: "2025-01-27",
      verifier: "London Chapter",
      image: "assets/images/london-apprentice.jpg",
      summary: "Monthly travel and lunch stipends for 16 apprentices in electrical, tailoring and kitchen trades.",
      body: "The stipend is deliberately modest — enough to remove the excuse, not enough to replace a wage. Recipients submit a weekly photo from the bench and a one-line note from their supervisor. Three apprentices have already been kept on as paid juniors.",
      witnesses: ["Amina Begum", "Daniel Osei"],
      documents: ["Stipend schedule", "Supervisor notes"]
    },
    {
      id: "AHY-2025-NG-041",
      title: "Sabon Gari street cleanse",
      category: "campaigns",
      country: "nigeria",
      date: "2025-04-05",
      verified: true,
      verifiedOn: "2025-04-07",
      verifier: "Kano Field Desk",
      image: "assets/images/kano-cleanup.jpg",
      summary: "120 youths, four streets, one Saturday. Tools remain in a community tool bank.",
      body: "Rather than a one-off spectacle, the cleanse was used to seed a tool bank that residents can borrow against a simple register. AHOY bought brooms, rakes, gloves and two wheelbarrows. The ward head countersigned the inventory.",
      witnesses: ["Hauwa Bello", "Musa Abdullahi"],
      documents: ["Tool-bank register", "Ward letter"]
    },
    {
      id: "AHY-2024-NG-112",
      title: "Ogun peri-urban field visit",
      category: "field-visits",
      country: "nigeria",
      date: "2024-09-18",
      verified: true,
      verifiedOn: "2024-09-22",
      verifier: "Verification Desk",
      image: "assets/images/field-visit.jpg",
      summary: "Unannounced visit to three garden-and-pump sites funded in 2023. All three still functioning.",
      body: "Field visits are scheduled by a desk that does not run the projects. The team photographed serial numbers on pumps, spoke to users without staff present, and compared findings to the original completion report. Variances are logged, not buried.",
      witnesses: ["Tunde Bakare", "Ngozi Ibe"],
      documents: ["Visit checklist", "Photo log", "Variance note"]
    },
    {
      id: "AHY-2023-EG-019",
      title: "Alexandria sewing & digital cohort",
      category: "trainings",
      country: "egypt",
      date: "2023-10-11",
      verified: true,
      verifiedOn: "2023-10-20",
      verifier: "Alexandria Chapter",
      image: "assets/images/training-workshop.jpg",
      summary: "Fourteen-week dual track: garment construction in the morning, spreadsheets and Arabic/English typing in the afternoon.",
      body: "Graduates received a machine-share arrangement rather than a machine of their own — four women rotate one industrial machine hosted at a member's flat. Income in the first quarter after graduation averaged EGP 2,400 a month among those who kept the share.",
      witnesses: ["Layla Hassan", "Nour El-Sayed"],
      documents: ["Cohort roster", "Share agreement"]
    },
    {
      id: "AHY-2024-CA-018",
      title: "Memorandum with Harbourfront Community Hub",
      category: "partnerships",
      country: "canada",
      date: "2024-06-03",
      verified: true,
      verifiedOn: "2024-06-10",
      verifier: "Partnerships Clerk",
      image: "assets/images/partnership.jpg",
      summary: "Three-year hall-and-kitchen access in exchange for AHOY running a monthly open workshop for the wider neighbourhood.",
      body: "No money changed hands. The memorandum is public. Either party may exit with 90 days' notice. The first twelve open workshops drew 310 unique visitors, of whom 41 later joined an AHOY circle.",
      witnesses: ["Elena Rossi", "Kwame Boateng"],
      documents: ["Signed memorandum", "Workshop counts"]
    },
    {
      id: "AHY-2025-UK-015",
      title: "Quiet leadership gathering, Greenwich",
      category: "events",
      country: "uk",
      date: "2025-05-17",
      verified: true,
      verifiedOn: "2025-05-20",
      verifier: "London Chapter",
      image: "assets/images/hero-youths.jpg",
      summary: "An evening by the river for 70 members. No keynote. Four short testimonies and a shared meal.",
      body: "AHOY events are kept inexpensive and unshowy on purpose. The Greenwich gathering cost £640, mostly food. Speakers were members, not guests. A written order of service is archived with the receipts.",
      witnesses: ["Sophie Clarke", "Ibrahim Diallo"],
      documents: ["Order of service", "Receipts bundle"]
    },
    {
      id: "AHY-2024-NG-077",
      title: "Stewardship Primer — second edition",
      category: "publications",
      country: "nigeria",
      date: "2024-08-01",
      verified: true,
      verifiedOn: "2024-08-04",
      verifier: "Publications Desk",
      image: "assets/images/training-workshop.jpg",
      summary: "A 48-page handbook on money, duty and speech, printed in English and Hausa. Distributed free to chapters.",
      body: "The Primer is AHOY's only standing publication. It is revised every two years by a rotating committee of members under 25. Print run of 2,000. PDF is free; print copies are given, never sold.",
      witnesses: ["Chinedu Obi", "Aisha Yusuf"],
      documents: ["Print invoice", "Hausa translation sign-off"]
    },
    {
      id: "AHY-2025-EG-009",
      title: "Case study: keeping a circle after the founder left",
      category: "case-studies",
      country: "egypt",
      date: "2025-03-01",
      verified: true,
      verifiedOn: "2025-03-05",
      verifier: "Learning Desk",
      image: "assets/images/cairo-mentorship.jpg",
      summary: "How the Heliopolis circle survived a leadership gap of five months without pausing meetings.",
      body: "When the founding mentor emigrated, the circle appointed two rotating chairs and cut the agenda in half. Attendance dipped then recovered. The case study is written for other chapters, not for donors.",
      witnesses: ["Mariam Saad"],
      documents: ["Case study PDF", "Attendance comparison"]
    },
    {
      id: "AHY-2023-CA-009",
      title: "Annual gathering photographs, Toronto",
      category: "media",
      country: "canada",
      date: "2023-11-25",
      verified: true,
      verifiedOn: "2023-12-01",
      verifier: "Archive Clerk",
      image: "assets/images/toronto-camp.jpg",
      summary: "A complete, consent-checked photo set from the 2023 gathering. Faces of minors are not published.",
      body: "AHOY's media rule is simple: no photograph of a person under 18 is published without a parent mark on the consent card, and even then we prefer hands-at-work over portraits. This set contains 86 images.",
      witnesses: ["Jordan Lee"],
      documents: ["Consent cards", "Contact sheet"]
    },
    {
      id: "AHY-2024-UK-022",
      title: "Mid-year chapter report, London",
      category: "reports",
      country: "uk",
      date: "2024-07-31",
      verified: true,
      verifiedOn: "2024-08-12",
      verifier: "Finance & Archive",
      image: "assets/images/london-apprentice.jpg",
      summary: "Spend, attendance and incidents for January–June 2024. Unqualified by the internal review.",
      body: "Chapter reports follow a fixed template: money in, money out, people served, things that went wrong. London recorded two late stipend payments and one unused hall booking. Both are explained in the notes.",
      witnesses: ["Claire Hughes"],
      documents: ["Chapter report", "Internal review note"]
    },
    {
      id: "AHY-2025-NG-002",
      title: "Partnership with Ward Education Desk, Alimosho",
      category: "partnerships",
      country: "nigeria",
      date: "2025-01-09",
      verified: true,
      verifiedOn: "2025-01-15",
      verifier: "Partnerships Clerk",
      image: "assets/images/partnership.jpg",
      summary: "Access to two classrooms on Saturday mornings for 24 months. AHOY provides facilitators; the ward provides the rooms.",
      body: "The letter of understanding is posted on the ward noticeboard and in this archive. AHOY does not pay sitting allowances to public officers.",
      witnesses: ["Bola Adeyemi"],
      documents: ["Letter of understanding"]
    },
    {
      id: "AHY-2024-EG-044",
      title: "Ramadan night school, Imbaba",
      category: "events",
      country: "egypt",
      date: "2024-03-22",
      verified: true,
      verifiedOn: "2024-04-15",
      verifier: "Cairo Chapter",
      image: "assets/images/cairo-mentorship.jpg",
      summary: "Literacy and accounts revision held after iftar for 28 out-of-school youths over 18 nights.",
      body: "Tutors were unpaid members. Food was provided by three neighbourhood families. AHOY paid only for lamps, exercise books and a night watchman.",
      witnesses: ["Hassan Mostafa", "Dina Adel"],
      documents: ["Night register", "Expense sheet"]
    },
    {
      id: "AHY-2023-NG-055",
      title: "Case study: why we stopped paying sitting allowances",
      category: "case-studies",
      country: "nigeria",
      date: "2023-06-14",
      verified: true,
      verifiedOn: "2023-06-20",
      verifier: "Learning Desk",
      image: "assets/images/field-visit.jpg",
      summary: "A frank account of how a 2019 habit distorted who showed up, and how the 2021 rule change reversed it.",
      body: "Between 2019 and 2021 AHOY paid small sitting allowances at community meetings. Attendance was high and contribution was low. The rule was dropped. Meetings shrank, then grew again with different people. The case is published so chapters do not relearn this the expensive way.",
      witnesses: ["Emeka Nwosu"],
      documents: ["Case study", "Board minute 2021-04"]
    },
    {
      id: "AHY-2025-CA-011",
      title: "Newcomer youth orientation, Rexdale",
      category: "trainings",
      country: "canada",
      date: "2025-04-19",
      verified: true,
      verifiedOn: "2025-04-24",
      verifier: "Toronto Steward",
      image: "assets/images/training-workshop.jpg",
      summary: "A six-Saturday orientation for recently arrived youths on transit, banking, libraries and how AHOY circles work.",
      body: "Run in English and French with Somali and Arabic whisper-translation. No immigration advice is given — we keep to practical civic navigation and introduce members to public services that already exist.",
      witnesses: ["Fatima Ali", "Marc Tremblay"],
      documents: ["Curriculum", "Language notes"]
    },
    {
      id: "AHY-2024-UK-031",
      title: "Field visit: Manchester bench placements",
      category: "field-visits",
      country: "uk",
      date: "2024-10-08",
      verified: true,
      verifiedOn: "2024-10-11",
      verifier: "Verification Desk",
      image: "assets/images/london-apprentice.jpg",
      summary: "Surprise visit to five workshops hosting AHOY apprentices. Four placements sound; one supervisor had left.",
      body: "The fifth placement was paused the same week and the apprentice moved. The visit note records the gap without blaming the remaining staff. This is the point of an independent desk.",
      witnesses: ["Hannah Price"],
      documents: ["Visit note", "Reassignment letter"]
    },
    {
      id: "AHY-2025-NG-019",
      title: "Photo essay: hands, not stages",
      category: "media",
      country: "nigeria",
      date: "2025-02-27",
      verified: true,
      verifiedOn: "2025-03-02",
      verifier: "Archive Clerk",
      image: "assets/images/vocational-kits.jpg",
      summary: "Forty-two photographs of work in progress — benches, gardens, registers — commissioned to replace hero-stage imagery.",
      body: "AHOY is retiring the habit of photographing youths on rented stages. This essay is the replacement house style: work, tools, paper, faces only when the person asks.",
      witnesses: ["Kemi Balogun"],
      documents: ["Photo essay", "Style note"]
    },
    {
      id: "AHY-2023-UK-014",
      title: "Pamphlet: How we count a youth served",
      category: "publications",
      country: "uk",
      date: "2023-05-02",
      verified: true,
      verifiedOn: "2023-05-08",
      verifier: "Publications Desk",
      image: "assets/images/training-workshop.jpg",
      summary: "A four-page rule so chapters cannot inflate numbers. One person, one programme, one year, one count.",
      body: "If a youth attends three trainings and a camp in the same year they are still counted once in the headline figure. Programme-level figures may list them again, clearly labelled. The pamphlet is binding.",
      witnesses: ["Owen Griffiths"],
      documents: ["Pamphlet v1", "Board adoption"]
    },
    {
      id: "AHY-2024-NG-101",
      title: "Annual activity report 2024 (Nigeria chapter)",
      category: "reports",
      country: "nigeria",
      date: "2025-02-15",
      verified: true,
      verifiedOn: "2025-02-28",
      verifier: "Finance & Archive",
      image: "assets/images/field-visit.jpg",
      summary: "Full-year Nigeria report: 1,184 unique youths, 11 projects, two qualified notes on late receipts.",
      body: "The Nigeria chapter is AHOY's largest. The 2024 report is published alongside the audited statements. Qualified notes concern two vendor receipts submitted after the books closed; both were resolved in Q1 2025.",
      witnesses: ["Olumide Fashola"],
      documents: ["Chapter report 2024", "Qualified notes"]
    },
    {
      id: "AHY-2025-EG-017",
      title: "Campaign: keep the Imbaba lamps lit",
      category: "campaigns",
      country: "egypt",
      date: "2025-01-12",
      verified: true,
      verifiedOn: "2025-01-18",
      verifier: "Cairo Chapter",
      image: "assets/images/cairo-mentorship.jpg",
      summary: "A small public appeal for replacement LED lamps and a year's electricity for the night school.",
      body: "Raised locally first. Only the unmet remainder was listed on the global campaigns page. This is AHOY's preferred order: neighbour, then chapter, then the wider fellowship.",
      witnesses: ["Youssef Nabil"],
      documents: ["Appeal note", "Electricity estimate"]
    },
    {
      id: "AHY-2023-CA-021",
      title: "Partnership: Toronto Public Library — study-hall nights",
      category: "partnerships",
      country: "canada",
      date: "2023-09-07",
      verified: true,
      verifiedOn: "2023-09-14",
      verifier: "Partnerships Clerk",
      image: "assets/images/partnership.jpg",
      summary: "Library provides space and a staff liaison; AHOY provides two quiet supervisors every Thursday in term.",
      body: "No grant, no branding wall. Members use the existing library cards. The partnership is reviewed each June.",
      witnesses: ["Amara Singh"],
      documents: ["Library letter"]
    }
  ],

  campaigns: [
    {
      id: "vocational-kits",
      title: "Fund vocational kits for 50 youths",
      country: "nigeria",
      image: "assets/images/vocational-kits.jpg",
      raised: 3200,
      goal: 5000,
      currency: "USD",
      status: "live",
      end: "2026-11-30",
      blurb: "A boxed kit — hand tools, tape, goggles, a notebook — and a 12-week coaching place beside a master craftsman.",
      story: "Most of the youths waiting on this list already have a bench to stand at. What they lack is their own tools, which means they borrow, wait, or are sent on errands. Fifty kits close that gap for the 2026 Agege and Kano cohorts. Every kit is photographed at handover and followed for six months.",
      costs: [
        { label: "One complete vocational kit", amount: 62 },
        { label: "Safety gear & first-aid pouch", amount: 18 },
        { label: "12-week coach stipend (shared)", amount: 14 },
        { label: "Tagging, photo log & follow-up", amount: 6 }
      ],
      unit: { amount: 100, label: "fully equips one youth for a year of placement" },
      updates: [
        { date: "2026-08-10", text: "32 kits procured. 18 still to fund." },
        { date: "2026-06-02", text: "Kano cohort list locked at 20 names; Agege at 30." }
      ]
    },
    {
      id: "stem-lab",
      title: "Keep the Yaba Girls STEM Lab open",
      country: "nigeria",
      image: "assets/images/stem-lab.jpg",
      raised: 8400,
      goal: 12000,
      currency: "USD",
      status: "live",
      end: "2026-12-15",
      blurb: "A year of Saturday laboratory time for 36 girls — laptops, parts, transport stipends and two mentors.",
      story: "The lab exists because a classroom is lent, not rented. What we must still pay for is the work itself: refurbished laptops, consumable parts, a small transport stipend so girls from farther neighbourhoods can actually arrive, and two mentors who show up every Saturday.",
      costs: [
        { label: "Refurbished laptop (shared pair)", amount: 180 },
        { label: "Parts & consumables / girl / year", amount: 45 },
        { label: "Transport stipend / girl / year", amount: 70 },
        { label: "Mentor honourarium / Saturday", amount: 28 }
      ],
      unit: { amount: 50, label: "covers one girl's transport for a full term" },
      updates: [
        { date: "2026-07-20", text: "Eight laptops refurbished and tagged." },
        { date: "2026-05-01", text: "2026 Saturday calendar agreed with the host school." }
      ]
    },
    {
      id: "cairo-circle",
      title: "Cairo mentorship circle — season six",
      country: "egypt",
      image: "assets/images/cairo-mentorship.jpg",
      raised: 1850,
      goal: 4000,
      currency: "USD",
      status: "live",
      end: "2026-10-31",
      blurb: "Tea, a room, and nine months of fortnightly circles for 54 mentees and 18 mentors.",
      story: "Nothing about this campaign is glamorous, which is the point. The circle has run for five seasons on almost no money. Season six needs a reliable room through the summer, a tiny tea budget, printed covenants, and two city-bus passes for mentors who cross the river.",
      costs: [
        { label: "Room hire / fortnight", amount: 22 },
        { label: "Tea & cups / gathering", amount: 8 },
        { label: "Printed covenants & notebooks", amount: 4 },
        { label: "Mentor bus pass / month", amount: 16 }
      ],
      unit: { amount: 25, label: "hosts one full circle evening" },
      updates: [
        { date: "2026-08-01", text: "Mentor covenant signed by 16 of 18." }
      ]
    },
    {
      id: "toronto-camp",
      title: "Winter skills camp, Scarborough",
      country: "canada",
      image: "assets/images/toronto-camp.jpg",
      raised: 6100,
      goal: 7500,
      currency: "USD",
      status: "live",
      end: "2026-12-01",
      blurb: "Four days between Christmas and New Year: first aid, carpentry and civic writing for 40 youths.",
      story: "The camp exists in the only week many school-age members are free. Hall, food, two certified instructors and a materials crate are the whole budget. Parents cook. AHOY does not fly anyone in.",
      costs: [
        { label: "Hall hire / day", amount: 280 },
        { label: "Meals / youth / day", amount: 18 },
        { label: "Red Cross instructor / day", amount: 240 },
        { label: "Materials crate (shared)", amount: 420 }
      ],
      unit: { amount: 90, label: "covers one youth for the full four days" },
      updates: [
        { date: "2026-07-15", text: "Hall reserved. Instructor contracts drafted." }
      ]
    },
    {
      id: "london-stipends",
      title: "East London apprenticeship stipends",
      country: "uk",
      image: "assets/images/london-apprentice.jpg",
      raised: 2400,
      goal: 10000,
      currency: "USD",
      status: "live",
      end: "2027-01-31",
      blurb: "Travel and lunch money for 16 apprentices so a placement does not collapse over a bus fare.",
      story: "The stipend is deliberately small. It is not a wage and we do not pretend it is. It is the difference between an apprentice who can cross London at 7 a.m. and one who quietly stops coming. Recipients send a weekly bench photo and a one-line supervisor note.",
      costs: [
        { label: "Travel / apprentice / month", amount: 85 },
        { label: "Lunch / apprentice / month", amount: 70 },
        { label: "Admin & verification / month", amount: 12 }
      ],
      unit: { amount: 155, label: "keeps one apprentice on the bench for a month" },
      updates: [
        { date: "2026-08-12", text: "Three 2025 apprentices kept on as paid juniors." },
        { date: "2026-04-03", text: "2026 cohort of 16 names confirmed." }
      ]
    },
    {
      id: "kano-tools",
      title: "Sabon Gari community tool bank",
      country: "nigeria",
      image: "assets/images/kano-cleanup.jpg",
      raised: 900,
      goal: 2000,
      currency: "USD",
      status: "live",
      end: "2026-09-30",
      blurb: "Brooms, rakes, gloves, two wheelbarrows — and a register so the street keeps them after the cameras leave.",
      story: "The cleanse already happened. What remains is to make the tools a neighbourhood asset rather than an AHOY prop. The ward head countersigns the register. Borrowers leave a name, not a deposit.",
      costs: [
        { label: "Wheelbarrow", amount: 48 },
        { label: "Dozen brooms & rakes", amount: 22 },
        { label: "Gloves & masks (50 sets)", amount: 35 },
        { label: "Lockable store latch & paint", amount: 18 }
      ],
      unit: { amount: 50, label: "puts a complete street kit on one block" },
      updates: [
        { date: "2026-04-07", text: "First cleanse complete. Register opened with 14 borrowers." }
      ]
    }
  ],

  finances: {
    headline: [
      { id: "programs", label: "Direct youth programmes", pct: 80, color: "#C9A227",
        note: "Kits, stipends, labs, camps, circles, field coaching." },
      { id: "operations", label: "Operations", pct: 12, color: "#1E4A73",
        note: "Lean chapter desks, audit, archive, insurance, connectivity." },
      { id: "outreach", label: "Community outreach", pct: 8, color: "#C41E3A",
        note: "Public gatherings, neighbour notices, translation, open workshops." }
    ],
    years: {
      2023: {
        income: 186400,
        spend: 179220,
        reserve: 7180,
        programs: 143376,
        operations: 21506,
        outreach: 14338,
        countries: { nigeria: 78000, egypt: 35200, canada: 33000, uk: 33020 },
        programsBreak: [
          { label: "Vocational kits & tools", amount: 41200 },
          { label: "Apprenticeship stipends", amount: 28600 },
          { label: "Trainings & circles", amount: 35400 },
          { label: "Camps & gatherings", amount: 22176 },
          { label: "Labs & learning materials", amount: 16000 }
        ],
        opsBreak: [
          { label: "Chapter desks (4 countries)", amount: 9800 },
          { label: "Audit & verification", amount: 5400 },
          { label: "Insurance & filings", amount: 3600 },
          { label: "Connectivity & archive", amount: 2706 }
        ],
        months: [9.2, 10.1, 12.4, 14.8, 15.2, 16.0, 14.1, 15.6, 17.2, 18.4, 19.0, 17.0]
      },
      2024: {
        income: 241800,
        spend: 228540,
        reserve: 13260,
        programs: 182832,
        operations: 27425,
        outreach: 18283,
        countries: { nigeria: 98000, egypt: 46200, canada: 42100, uk: 42240 },
        programsBreak: [
          { label: "Vocational kits & tools", amount: 52800 },
          { label: "Apprenticeship stipends", amount: 36400 },
          { label: "Trainings & circles", amount: 44100 },
          { label: "Camps & gatherings", amount: 27332 },
          { label: "Labs & learning materials", amount: 22200 }
        ],
        opsBreak: [
          { label: "Chapter desks (4 countries)", amount: 12200 },
          { label: "Audit & verification", amount: 6800 },
          { label: "Insurance & filings", amount: 4400 },
          { label: "Connectivity & archive", amount: 4025 }
        ],
        months: [12.4, 13.0, 15.8, 18.2, 19.4, 20.1, 18.8, 20.4, 22.0, 23.6, 24.1, 20.7]
      },
      2025: {
        income: 198600,
        spend: 174900,
        reserve: 23700,
        programs: 139920,
        operations: 20988,
        outreach: 13992,
        countries: { nigeria: 76000, egypt: 34200, canada: 32400, uk: 32300 },
        programsBreak: [
          { label: "Vocational kits & tools", amount: 38600 },
          { label: "Apprenticeship stipends", amount: 29800 },
          { label: "Trainings & circles", amount: 34200 },
          { label: "Camps & gatherings", amount: 20120 },
          { label: "Labs & learning materials", amount: 17200 }
        ],
        opsBreak: [
          { label: "Chapter desks (4 countries)", amount: 9400 },
          { label: "Audit & verification", amount: 5200 },
          { label: "Insurance & filings", amount: 3388 },
          { label: "Connectivity & archive", amount: 3000 }
        ],
        months: [11.2, 12.8, 14.6, 16.4, 17.1, 18.0, 19.2, 18.4, 0, 0, 0, 0]
      }
    }
  },

  reports: [
    { id: "ar-2025", title: "Annual Report 2025 (year to date)", type: "annual", year: 2025, date: "2026-02-01", file: "reports/annual-2025.html", pages: 28, status: "Unaudited YTD" },
    { id: "ar-2024", title: "Annual Report 2024", type: "annual", year: 2024, date: "2025-03-18", file: "reports/annual-2024.html", pages: 36, status: "Published" },
    { id: "ar-2023", title: "Annual Report 2023", type: "annual", year: 2023, date: "2024-03-22", file: "reports/annual-2023.html", pages: 32, status: "Published" },
    { id: "af-2024", title: "Audited Financial Statements 2024", type: "audit", year: 2024, date: "2025-04-09", file: "reports/audit-2024.html", pages: 22, status: "Unqualified opinion" },
    { id: "af-2023", title: "Audited Financial Statements 2023", type: "audit", year: 2023, date: "2024-04-11", file: "reports/audit-2023.html", pages: 20, status: "Unqualified opinion" },
    { id: "my-2025", title: "Mid-year Financial Brief 2025", type: "brief", year: 2025, date: "2025-08-20", file: "reports/midyear-2025.html", pages: 8, status: "Published" }
  ],

  donations: [
    { id: "don-1001", campaign: "vocational-kits", amount: 100, method: "paystack", name: "Anonymous", date: "2026-08-12", public: false },
    { id: "don-1002", campaign: "stem-lab", amount: 250, method: "stripe", name: "R. Adeyemi", date: "2026-08-08", public: true },
    { id: "don-1003", campaign: "cairo-circle", amount: 50, method: "paypal", name: "M. Farouk", date: "2026-07-30", public: true },
    { id: "don-1004", campaign: "london-stipends", amount: 155, method: "bank", name: "Anonymous", date: "2026-07-22", public: false },
    { id: "don-1005", campaign: "toronto-camp", amount: 90, method: "stripe", name: "J. Okello", date: "2026-07-18", public: true }
  ],

  admin: {
    email: "steward@ahoyyouths.org",
    // password is hashed at seed time in store.js — default: HarbourWheel.26
    passwordHash: "",
    passwordPlainForDemo: "HarbourWheel.26"
  }
};
