document.addEventListener("DOMContentLoaded", () => {
  const app = document.getElementById("app");
  let view = "overview";
  let editItem = null;
  let editCamp = null;

  function draw() {
    const sess = AHOY.session();
    if (!sess) { drawLogin(); return; }
    drawApp(sess);
  }

  function drawLogin() {
    const admin = AHOY.get().admin;
    app.innerHTML = `
      <div class="login-shell">
        <form class="login-card" id="login">
          <a href="index.html" class="brand" style="margin-bottom:16px">
            <img src="assets/logo.png" alt="AHOY" style="height:40px;width:auto">
            <span class="word"><span>Steward desk</span></span>
          </a>
          <h1>Sign in to the desk</h1>
          <p class="muted">Session lives in this browser only and expires after eight hours. Nothing here is a real bank or identity system.</p>
          <div class="demo">
            Demo steward<br>
            ${admin.email}<br>
            ${admin.passwordPlainForDemo}
          </div>
          <div class="field"><label>Email</label><input id="em" type="email" autocomplete="username" required></div>
          <div class="field"><label>Password</label><input id="pw" type="password" autocomplete="current-password" required></div>
          <p id="err" style="color:#ff8a9a;font-size:.86rem;display:none"></p>
          <button class="btn btn-gold" style="width:100%">Enter the desk</button>
          <p style="text-align:center;margin:16px 0 0"><a href="index.html" style="color:var(--gold-300);font-size:.86rem">← Back to the public site</a></p>
        </form>
      </div>`;
    document.getElementById("login").addEventListener("submit", e => {
      e.preventDefault();
      const res = AHOY.login(document.getElementById("em").value, document.getElementById("pw").value);
      if (!res.ok) {
        const err = document.getElementById("err");
        err.style.display = "block";
        err.textContent = res.error;
        return;
      }
      view = "overview";
      draw();
    });
  }

  function navBtn(id, label) {
    return `<button class="navb ${view===id?"on":""}" data-v="${id}">${label}</button>`;
  }

  function drawApp(sess) {
    const s = AHOY.get();
    app.innerHTML = `
      <div class="admin-app">
        <aside class="aside">
          <a href="index.html" class="brand" style="margin:4px 8px 18px">
            <img src="assets/logo.png" alt="AHOY" style="height:32px;width:auto">
            <span class="word"><span>Steward</span></span>
          </a>
          ${navBtn("overview","Overview")}
          ${navBtn("archive","Archive records")}
          ${navBtn("campaigns","Campaigns")}
          ${navBtn("gifts","Gift ledger")}
          ${navBtn("money","Allocation")}
          ${navBtn("reports","Reports")}
          ${navBtn("letters","Letters")}
          <button class="navb" id="out" style="margin-top:18px">Sign out</button>
        </aside>
        <main class="admin-main" id="main"></main>
      </div>`;
    app.querySelectorAll("[data-v]").forEach(b => b.onclick = () => { view = b.dataset.v; editItem = null; editCamp = null; draw(); });
    document.getElementById("out").onclick = () => { AHOY.logout(); draw(); };

    const main = document.getElementById("main");
    if (view === "overview") main.innerHTML = overview(s, sess);
    if (view === "archive") main.innerHTML = archive(s);
    if (view === "campaigns") main.innerHTML = camps(s);
    if (view === "gifts") main.innerHTML = gifts(s);
    if (view === "money") main.innerHTML = money(s);
    if (view === "reports") main.innerHTML = reports(s);
    if (view === "letters") main.innerHTML = letters();
    bindView();
  }

  function overview(s, sess) {
    const raised = s.campaigns.reduce((a,c)=>a+c.raised,0);
    const goal = s.campaigns.reduce((a,c)=>a+c.goal,0);
    return `
      <div class="admin-top">
        <div>
          <div class="kicker">Signed in as ${sess.email}</div>
          <h2>Desk overview</h2>
        </div>
        <button class="btn btn-line btn-sm" id="reset">Reset demo data</button>
      </div>
      <div class="stat-cards">
        <div class="stat"><div class="lab">Archive records</div><div class="num">${s.items.length}</div></div>
        <div class="stat"><div class="lab">Live campaigns</div><div class="num">${s.campaigns.length}</div></div>
        <div class="stat"><div class="lab">Raised / goal</div><div class="num">${UI.money(raised)}</div><div class="muted">of ${UI.money(goal)}</div></div>
        <div class="stat"><div class="lab">Gifts on file</div><div class="num">${s.donations.length}</div></div>
      </div>
      <div class="panel">
        <h3 style="color:#fff">Recent activity</h3>
        ${(s.activity||[]).slice(0,12).map(a => `<p class="muted" style="margin:8px 0">${new Date(a.at).toLocaleString()} · ${a.actor} · ${a.action}</p>`).join("")}
      </div>`;
  }

  function archive(s) {
    if (editItem) return itemForm(editItem);
    return `
      <div class="admin-top">
        <h2>Archive records</h2>
        <button class="btn btn-gold btn-sm" id="new-item">New record</button>
      </div>
      <div class="panel table-wrap">
        <table class="data">
          <thead><tr><th>ID</th><th>Title</th><th>Category</th><th>Country</th><th>Verified</th><th></th></tr></thead>
          <tbody>
            ${s.items.map(i => `<tr>
              <td class="mono">${i.id}</td>
              <td>${i.title}</td>
              <td>${i.category}</td>
              <td>${i.country}</td>
              <td>${i.verified ? "yes" : "no"}</td>
              <td>
                <button class="btn btn-sm btn-line" data-edit="${i.id}">Edit</button>
                <button class="btn btn-sm btn-crimson" data-del="${i.id}">Remove</button>
              </td>
            </tr>`).join("")}
          </tbody>
        </table>
      </div>`;
  }

  function itemForm(it) {
    const isNew = it.__new;
    const video = it.video || null;
    const vType = video ? video.type : "none";
    return `
      <div class="admin-top"><h2>${isNew ? "New archive record" : "Edit record"}</h2>
        <button class="btn btn-line btn-sm" id="cancel">Cancel</button></div>
      <form class="panel" id="item-form">
        <div class="grid-2">
          <div class="field"><label>Archive ID</label><input name="id" value="${it.id||""}" ${isNew?"":"readonly"}></div>
          <div class="field"><label>Date</label><input name="date" type="date" value="${it.date||""}"></div>
          <div class="field"><label>Title</label><input name="title" value="${esc(it.title||"")}"></div>
          <div class="field">
            <label>Image</label>
            <div class="upload-field">
              <img class="upload-preview" id="image-preview" src="${it.image||"assets/images/field-visit.jpg"}" alt="">
              <div class="upload-controls">
                <input type="file" id="image-file" accept="image/*">
                <span class="upload-hint">Upload a photo to replace the current image.</span>
              </div>
            </div>
            <input type="hidden" name="image" id="image-value" value="${it.image||"assets/images/field-visit.jpg"}">
          </div>
          <div class="field"><label>Category</label>
            <select name="category">${AHOY.categories().map(c => `<option value="${c.id}" ${c.id===it.category?"selected":""}>${c.name}</option>`).join("")}</select>
          </div>
          <div class="field"><label>Country</label>
            <select name="country">${AHOY.countries().map(c => `<option value="${c.id}" ${c.id===it.country?"selected":""}>${c.name}</option>`).join("")}</select>
          </div>
        </div>
        <div class="field"><label>Summary</label><textarea name="summary" rows="2">${esc(it.summary||"")}</textarea></div>
        <div class="field"><label>Body</label><textarea name="body" rows="5">${esc(it.body||"")}</textarea></div>
        <div class="grid-2">
          <div class="field"><label>Verifier</label><input name="verifier" value="${esc(it.verifier||"")}"></div>
          <div class="field"><label>Verified on</label><input name="verifiedOn" type="date" value="${it.verifiedOn||""}"></div>
          <div class="field"><label>Witnesses (comma)</label><input name="witnesses" value="${(it.witnesses||[]).join(", ")}"></div>
          <div class="field"><label>Documents (comma)</label><input name="documents" value="${(it.documents||[]).join(", ")}"></div>
        </div>
        <div class="field">
          <label>Video (optional)</label>
          <div class="video-type-toggle">
            <label><input type="radio" name="videoType" value="none" ${vType==="none"?"checked":""}> No video</label>
            <label><input type="radio" name="videoType" value="youtube" ${vType==="youtube"?"checked":""}> YouTube link</label>
            <label><input type="radio" name="videoType" value="file" ${vType==="file"?"checked":""}> Upload file</label>
          </div>
          <input type="url" name="videoYoutube" id="video-youtube" placeholder="https://www.youtube.com/watch?v=…" value="${vType==="youtube"?esc(video.url||""):""}" class="${vType==="youtube"?"":"hidden"}">
          <div class="upload-field video-file-row ${vType==="file"?"":"hidden"}" id="video-file-row">
            <div class="upload-controls">
              <input type="file" id="video-file" accept="video/*">
              <span class="upload-hint">${vType==="file"&&video&&video.url?"A video file is already attached. Choose a new one to replace it.":"MP4 or WebM recommended. Large files may exceed local demo storage."}</span>
            </div>
          </div>
          <input type="hidden" name="videoFileData" id="video-file-value" value="${vType==="file"?esc(video.url||""):""}">
        </div>
        <label class="flex" style="margin:8px 0 16px"><input type="checkbox" name="verified" ${it.verified?"checked":""}> Mark verified</label>
        <button class="btn btn-gold">Save record</button>
      </form>`;
  }

  function camps(s) {
    if (editCamp) return campForm(editCamp);
    return `
      <div class="admin-top">
        <h2>Campaigns</h2>
        <button class="btn btn-gold btn-sm" id="new-camp">New campaign</button>
      </div>
      <div class="panel table-wrap">
        <table class="data">
          <thead><tr><th>ID</th><th>Title</th><th>Raised</th><th>Goal</th><th>%</th><th></th></tr></thead>
          <tbody>
            ${s.campaigns.map(c => `<tr>
              <td class="mono">${c.id}</td><td>${c.title}</td>
              <td>${UI.money(c.raised)}</td><td>${UI.money(c.goal)}</td>
              <td>${UI.pct(c.raised,c.goal)}%</td>
              <td>
                <button class="btn btn-sm btn-line" data-cedit="${c.id}">Edit</button>
                <button class="btn btn-sm btn-crimson" data-cdel="${c.id}">Remove</button>
              </td>
            </tr>`).join("")}
          </tbody>
        </table>
      </div>`;
  }

  function campForm(c) {
    return `
      <div class="admin-top"><h2>${c.__new ? "New campaign" : "Edit campaign"}</h2>
        <button class="btn btn-line btn-sm" id="cancel">Cancel</button></div>
      <form class="panel" id="camp-form">
        <div class="grid-2">
          <div class="field"><label>ID (slug)</label><input name="id" value="${c.id||""}" ${c.__new?"":"readonly"}></div>
          <div class="field"><label>Title</label><input name="title" value="${esc(c.title||"")}"></div>
          <div class="field"><label>Country</label>
            <select name="country">${AHOY.countries().map(x => `<option value="${x.id}" ${x.id===c.country?"selected":""}>${x.name}</option>`).join("")}</select>
          </div>
          <div class="field">
            <label>Image</label>
            <div class="upload-field">
              <img class="upload-preview" id="camp-image-preview" src="${c.image||"assets/images/vocational-kits.jpg"}" alt="">
              <div class="upload-controls">
                <input type="file" id="camp-image-file" accept="image/*">
                <span class="upload-hint">Upload a photo to replace the current image.</span>
              </div>
            </div>
            <input type="hidden" name="image" id="camp-image-value" value="${c.image||"assets/images/vocational-kits.jpg"}">
          </div>
          <div class="field"><label>Raised (USD)</label><input name="raised" type="number" value="${c.raised||0}"></div>
          <div class="field"><label>Goal (USD)</label><input name="goal" type="number" value="${c.goal||1000}"></div>
          <div class="field"><label>Closes</label><input name="end" type="date" value="${c.end||""}"></div>
          <div class="field"><label>Unit amount</label><input name="unitAmount" type="number" value="${(c.unit&&c.unit.amount)||50}"></div>
        </div>
        <div class="field"><label>Unit label</label><input name="unitLabel" value="${esc((c.unit&&c.unit.label)||"")}"></div>
        <div class="field"><label>Short blurb</label><textarea name="blurb" rows="2">${esc(c.blurb||"")}</textarea></div>
        <div class="field"><label>Story</label><textarea name="story" rows="5">${esc(c.story||"")}</textarea></div>
        <div class="field"><label>Cost lines (label | amount, one per line)</label>
          <textarea name="costs" rows="4">${(c.costs||[]).map(x => x.label + " | " + x.amount).join("\n")}</textarea>
        </div>
        <button class="btn btn-gold">Save campaign</button>
      </form>`;
  }

  function gifts(s) {
    return `
      <div class="admin-top"><h2>Gift ledger</h2></div>
      <div class="panel table-wrap">
        <table class="data">
          <thead><tr><th>Ref</th><th>Date</th><th>Campaign</th><th>Amount</th><th>Method</th><th>Name</th></tr></thead>
          <tbody>
            ${s.donations.map(d => `<tr>
              <td class="mono">${d.id}</td><td>${d.date}</td><td>${d.campaign}</td>
              <td>${UI.money2(d.amount)}</td><td>${d.method}</td><td>${d.name}</td>
            </tr>`).join("") || `<tr><td colspan="6" class="muted">No gifts yet.</td></tr>`}
          </tbody>
        </table>
      </div>`;
  }

  function money(s) {
    const h = s.finances.headline;
    return `
      <div class="admin-top"><h2>Headline allocation</h2></div>
      <form class="panel" id="alloc-form">
        <p class="muted">These three numbers must add to 100. They drive the public pie charts.</p>
        ${h.map((x,i) => `
          <div class="grid-2">
            <div class="field"><label>Label ${i+1}</label><input name="label${i}" value="${esc(x.label)}"></div>
            <div class="field"><label>Percent</label><input name="pct${i}" type="number" value="${x.pct}"></div>
          </div>`).join("")}
        <button class="btn btn-gold">Save allocation</button>
      </form>`;
  }

  function reports(s) {
    return `
      <div class="admin-top"><h2>Published reports</h2></div>
      <form class="panel" id="rep-form">
        <div class="grid-2">
          <div class="field"><label>Title</label><input name="title" required></div>
          <div class="field"><label>Year</label><input name="year" type="number" value="2026"></div>
          <div class="field"><label>Type</label>
            <select name="type"><option value="annual">Annual</option><option value="audit">Audit</option><option value="brief">Brief</option></select>
          </div>
          <div class="field"><label>File path</label><input name="file" value="reports/annual-2025.html"></div>
          <div class="field"><label>Pages</label><input name="pages" type="number" value="12"></div>
          <div class="field"><label>Status</label><input name="status" value="Published"></div>
        </div>
        <button class="btn btn-gold">Add to archive</button>
      </form>
      <div class="panel">
        ${s.reports.map(r => `<div class="flex" style="justify-content:space-between;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.06)">
          <div><b style="color:#fff">${r.title}</b><div class="muted">${r.status} · ${r.year}</div></div>
          <button class="btn btn-sm btn-crimson" data-rdel="${r.id}">Remove</button>
        </div>`).join("")}
      </div>`;
  }

  function letters() {
    const list = JSON.parse(localStorage.getItem("ahoy.letters") || "[]");
    return `
      <div class="admin-top"><h2>Letters from the public site</h2></div>
      <div class="panel">
        ${list.length ? list.map(l => `<div style="padding:12px 0;border-bottom:1px solid rgba(255,255,255,.06)">
          <b style="color:#fff">${esc(l.n)}</b> · ${esc(l.e)} · ${esc(l.t)}
          <div class="muted">${new Date(l.at).toLocaleString()}</div>
          <p>${esc(l.m)}</p>
        </div>`).join("") : `<p class="muted">No letters yet.</p>`}
      </div>`;
  }

  function esc(s) {
    return String(s).replace(/[&<>"']/g, ch => ({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;" }[ch]));
  }

  function formObj(form) {
    return Object.fromEntries(new FormData(form).entries());
  }

  function readFileInto(fileInputId, previewIds, valueId) {
    const input = document.getElementById(fileInputId);
    if (!input) return;
    input.addEventListener("change", () => {
      const f = input.files[0];
      if (!f) return;
      if (f.size > 25 * 1024 * 1024) {
        UI.toast("That file is quite large for local demo storage — try a smaller one.");
      }
      const reader = new FileReader();
      reader.onload = () => {
        previewIds.forEach(id => {
          const el = document.getElementById(id);
          if (el) el.src = reader.result;
        });
        const val = document.getElementById(valueId);
        if (val) val.value = reader.result;
      };
      reader.readAsDataURL(f);
    });
  }

  function bindView() {
    const reset = document.getElementById("reset");
    if (reset) reset.onclick = () => {
      if (confirm("Restore the original demo archive, campaigns and gifts?")) {
        AHOY.reset();
        UI.toast("Demo data restored.");
        draw();
      }
    };
    document.querySelectorAll("[data-edit]").forEach(b => b.onclick = () => {
      editItem = AHOY.item(b.dataset.edit); draw();
    });
    document.querySelectorAll("[data-del]").forEach(b => b.onclick = () => {
      if (confirm("Remove this record from the public archive?")) { AHOY.deleteItem(b.dataset.del); draw(); }
    });
    const ni = document.getElementById("new-item");
    if (ni) ni.onclick = () => {
      editItem = { __new: true, id: "AHY-" + new Date().getFullYear() + "-XX-" + String(Math.floor(Math.random()*900)+100),
        date: new Date().toISOString().slice(0,10), verified: false, category: "projects", country: "nigeria",
        image: "assets/images/field-visit.jpg", documents: [], witnesses: [], video: null };
      draw();
    };
    const cancel = document.getElementById("cancel");
    if (cancel) cancel.onclick = () => { editItem = null; editCamp = null; draw(); };

    readFileInto("image-file", ["image-preview"], "image-value");
    readFileInto("video-file", [], "video-file-value");

    document.querySelectorAll('input[name="videoType"]').forEach(r => r.addEventListener("change", () => {
      const val = document.querySelector('input[name="videoType"]:checked').value;
      const yt = document.getElementById("video-youtube");
      const vfRow = document.getElementById("video-file-row");
      if (yt) yt.classList.toggle("hidden", val !== "youtube");
      if (vfRow) vfRow.classList.toggle("hidden", val !== "file");
    }));

    const itemFormEl = document.getElementById("item-form");
    if (itemFormEl) itemFormEl.onsubmit = e => {
      e.preventDefault();
      const o = formObj(itemFormEl);
      let video = null;
      if (o.videoType === "youtube" && o.videoYoutube && o.videoYoutube.trim()) {
        video = { type: "youtube", url: o.videoYoutube.trim() };
      } else if (o.videoType === "file" && o.videoFileData) {
        video = { type: "file", url: o.videoFileData };
      }
      try {
        AHOY.upsertItem({
          id: o.id, title: o.title, category: o.category, country: o.country, date: o.date,
          verified: itemFormEl.verified.checked, verifiedOn: o.verifiedOn, verifier: o.verifier,
          image: o.image, summary: o.summary, body: o.body,
          witnesses: o.witnesses.split(",").map(x => x.trim()).filter(Boolean),
          documents: o.documents.split(",").map(x => x.trim()).filter(Boolean),
          video
        });
        editItem = null; UI.toast("Record saved."); draw();
      } catch (err) {
        UI.toast("Could not save — the uploaded file may be too large for this browser's local storage.");
      }
    };

    document.querySelectorAll("[data-cedit]").forEach(b => b.onclick = () => {
      editCamp = AHOY.campaign(b.dataset.cedit); draw();
    });
    document.querySelectorAll("[data-cdel]").forEach(b => b.onclick = () => {
      if (confirm("Remove this campaign?")) { AHOY.deleteCampaign(b.dataset.cdel); draw(); }
    });
    const nc = document.getElementById("new-camp");
    if (nc) nc.onclick = () => {
      editCamp = { __new: true, id: "new-need", raised: 0, goal: 2500, status: "live",
        country: "nigeria", currency: "USD", costs: [], unit: { amount: 50, label: "" }, updates: [] };
      draw();
    };
    readFileInto("camp-image-file", ["camp-image-preview"], "camp-image-value");
    const campFormEl = document.getElementById("camp-form");
    if (campFormEl) campFormEl.onsubmit = e => {
      e.preventDefault();
      const o = formObj(campFormEl);
      const prev = AHOY.campaign(o.id) || {};
      AHOY.upsertCampaign({
        ...prev,
        id: o.id, title: o.title, country: o.country, image: o.image,
        raised: Number(o.raised), goal: Number(o.goal), end: o.end,
        blurb: o.blurb, story: o.story, status: prev.status || "live", currency: "USD",
        unit: { amount: Number(o.unitAmount), label: o.unitLabel },
        costs: o.costs.split("\n").map(line => {
          const [label, amount] = line.split("|").map(x => x && x.trim());
          if (!label) return null;
          return { label, amount: Number(amount) || 0 };
        }).filter(Boolean),
        updates: prev.updates || []
      });
      editCamp = null; UI.toast("Campaign saved."); draw();
    };

    const alloc = document.getElementById("alloc-form");
    if (alloc) alloc.onsubmit = e => {
      e.preventDefault();
      const o = formObj(alloc);
      const colors = ["#C9A227", "#1E4A73", "#C41E3A"];
      const notes = AHOY.get().finances.headline.map(x => x.note);
      const headline = [0,1,2].map(i => ({
        id: ["programs","operations","outreach"][i],
        label: o["label"+i], pct: Number(o["pct"+i]), color: colors[i], note: notes[i]
      }));
      const sum = headline.reduce((a,x)=>a+x.pct,0);
      if (sum !== 100) { UI.toast("Percents must add to 100 (now " + sum + ")."); return; }
      AHOY.setHeadline(headline);
      UI.toast("Allocation updated."); draw();
    };

    const rf = document.getElementById("rep-form");
    if (rf) rf.onsubmit = e => {
      e.preventDefault();
      const o = formObj(rf);
      AHOY.addReport({
        id: "rep-" + Date.now(), title: o.title, type: o.type, year: Number(o.year),
        date: new Date().toISOString().slice(0,10), file: o.file, pages: Number(o.pages), status: o.status
      });
      UI.toast("Report listed."); draw();
    };
    document.querySelectorAll("[data-rdel]").forEach(b => b.onclick = () => {
      AHOY.deleteReport(b.dataset.rdel); draw();
    });
  }

  draw();
});
