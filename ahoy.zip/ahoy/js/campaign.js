document.addEventListener("DOMContentLoaded", () => {
  const id = UI.qs("id");
  const root = document.getElementById("root");
  let camp = AHOY.campaign(id);
  if (!camp) {
    root.innerHTML = `<div class="wrap"><h1>Campaign not found</h1><p><a href="campaigns.html">Back to campaigns</a></p></div>`;
    return;
  }
  document.title = camp.title + " — AHOY";

  let amount = camp.unit.amount;
  let method = "stripe";

  function paint() {
    camp = AHOY.campaign(id);
    const co = UI.country(camp.country);
    const p = UI.pct(camp.raised, camp.goal);
    const remain = Math.max(0, camp.goal - camp.raised);
    root.innerHTML = `
      <div class="wrap">
        <p class="muted"><a href="campaigns.html">← All campaigns</a></p>
        <div class="camp-hero">
          <div>
            <div class="shot"><img src="${camp.image}" alt=""></div>
            <div class="meta-row mt">
              <span class="pill pill-live">${camp.status === "live" ? "Live" : camp.status}</span>
              <span class="pill pill-gold">${co.flag} ${co.name}</span>
              <span class="pill">Closes ${UI.formatDate(camp.end)}</span>
            </div>
            <h1 style="margin-top:12px">${camp.title}</h1>
            <p>${camp.story}</p>
            <h3>What one gift actually buys</h3>
            <table class="cost-table">
              ${(camp.costs||[]).map(c => `<tr><td>${c.label}</td><td>${UI.money2(c.amount)}</td></tr>`).join("")}
            </table>
            <p class="muted">$${camp.unit.amount} ${camp.unit.label}.</p>
            <h3 class="mt">Campaign notes</h3>
            ${(camp.updates||[]).map(u => `<p><b>${UI.formatDate(u.date)}.</b> ${u.text}</p>`).join("") || "<p class='muted'>No notes yet.</p>"}
          </div>
          <aside class="pledge" id="pledge">
            <div class="fund-meta"><b>${UI.money(camp.raised)}</b><span>raised of ${UI.money(camp.goal)}</span></div>
            <div class="progress"><span style="width:${p}%"></span></div>
            <p class="muted" style="margin:10px 0 16px">${p}% · ${UI.money(remain)} still needed</p>
            <div id="form-slot">${formHTML()}</div>
          </aside>
        </div>
      </div>`;
    bindForm();
  }

  function formHTML() {
    return `
      <label class="field"><span>Your gift (USD)</span></label>
      <div class="amounts" id="amts">
        ${[25,50,camp.unit.amount,250,500].filter((v,i,a)=>a.indexOf(v)===i).map(v =>
          `<button type="button" data-amt="${v}" class="${v===amount?"on":""}">$${v}</button>`).join("")}
      </div>
      <div class="field"><input id="custom" type="number" min="5" step="1" placeholder="Or another amount" value="${amount}"></div>
      <p class="muted" style="font-size:.82rem" id="impact"></p>
      <div class="field"><label>How would you like to give?</label></div>
      <div class="pay-grid" id="methods">
        <button type="button" class="pay-opt ${method==="stripe"?"on":""}" data-m="stripe">Card · Stripe</button>
        <button type="button" class="pay-opt ${method==="paypal"?"on":""}" data-m="paypal">PayPal</button>
        <button type="button" class="pay-opt ${method==="paystack"?"on":""}" data-m="paystack">Paystack</button>
        <button type="button" class="pay-opt ${method==="bank"?"on":""}" data-m="bank">Bank transfer</button>
        <button type="button" class="pay-opt ${method==="ussd"?"on":""}" data-m="ussd">USSD (NG)</button>
        <button type="button" class="pay-opt ${method==="crypto"?"on":""}" data-m="crypto">Crypto</button>
      </div>
      <div class="pay-panel ${method==="stripe"||method==="paystack"?"on":""}" id="p-card">
        <div class="field"><label>Name on card</label><input id="cardname" placeholder="As printed"></div>
        <div class="field"><label>Card number</label><input id="cardnum" inputmode="numeric" placeholder="4242 4242 4242 4242" maxlength="19"></div>
        <div class="grid-2">
          <div class="field"><label>Expiry</label><input id="exp" placeholder="MM/YY"></div>
          <div class="field"><label>CVC</label><input id="cvc" placeholder="123" maxlength="4"></div>
        </div>
      </div>
      <div class="pay-panel ${method==="paypal"?"on":""}" id="p-paypal">
        <p class="muted">You will be shown a PayPal confirmation on this page. No account is charged — this is a demonstration gateway.</p>
      </div>
      <div class="pay-panel ${method==="bank"?"on":""}" id="p-bank">
        <div class="bank">
          AHOY Stewardship Account<br>
          GTBank · 0178842291 · AHOY YOUTHS<br>
          USD correspondent: CIBC · 000245119<br>
          Reference: ${camp.id.toUpperCase()}-YOURNAME
        </div>
        <p class="muted" style="margin-top:8px">Mark the gift below once you have sent the transfer. A steward will match it to the bank file.</p>
      </div>
      <div class="pay-panel ${method==="ussd"?"on":""}" id="p-ussd">
        <div class="ussd">
          *737*${Math.round(amount * 1550)}*0178842291#<br>
          *901*${Math.round(amount * 1550)}*0178842291#<br>
          *894*${Math.round(amount * 1550)}*0178842291#
        </div>
        <p class="muted" style="margin-top:8px">GTBank, Access and FCMB short codes. Amount shown in naira at a demo rate of ₦1,550 / USD.</p>
      </div>
      <div class="pay-panel ${method==="crypto"?"on":""}" id="p-crypto">
        <div class="crypto">
          BTC  bc1qahoydemo000verifyonly000x7k2<br>
          ETH  0xAHOY0000000000000000dEmoOnly89<br>
          USDT (TRC20)  TAhoyDemoOnlyDoNotSend999
        </div>
        <p class="muted" style="margin-top:8px">Demonstration addresses. Do not send real assets.</p>
      </div>
      <div class="field"><label>Name to show (optional)</label><input id="pname" placeholder="Leave blank to stay anonymous"></div>
      <label class="flex" style="font-size:.88rem;margin:8px 0 14px">
        <input type="checkbox" id="pub"> List my name on this campaign
      </label>
      <div class="notice">Demonstration checkout. No card is charged, no wallet is debited. The progress bar will still move so you can see the tracker work.</div>
      <button class="btn btn-gold" id="give" style="width:100%;margin-top:14px">Give ${UI.money2(amount)} via ${labelOf(method)}</button>
    `;
  }

  function labelOf(m) {
    return ({ stripe:"card", paypal:"PayPal", paystack:"Paystack", bank:"bank transfer", ussd:"USSD", crypto:"crypto" })[m] || m;
  }

  function bindForm() {
    const impact = document.getElementById("impact");
    const units = Math.max(1, Math.round(amount / camp.unit.amount * 10) / 10);
    impact.textContent = `About ${units}× — ${camp.unit.label}.`;

    document.getElementById("amts").addEventListener("click", e => {
      const b = e.target.closest("[data-amt]");
      if (!b) return;
      amount = Number(b.dataset.amt);
      paint();
    });
    document.getElementById("custom").addEventListener("change", e => {
      amount = Math.max(5, Number(e.target.value) || 5);
      paint();
    });
    document.getElementById("methods").addEventListener("click", e => {
      const b = e.target.closest("[data-m]");
      if (!b) return;
      method = b.dataset.m;
      paint();
    });
    document.getElementById("give").addEventListener("click", submit);
  }

  function submit() {
    if (method === "stripe" || method === "paystack") {
      const num = (document.getElementById("cardnum") || {}).value || "";
      if (num.replace(/\s/g, "").length < 12) {
        UI.toast("Enter a demo card number (any 12+ digits).");
        return;
      }
    }
    const name = (document.getElementById("pname") || {}).value || "";
    const isPub = (document.getElementById("pub") || {}).checked;
    try {
      AHOY.donate({ campaign: camp.id, amount, method, name, public: isPub });
    } catch (err) {
      UI.toast(err.message); return;
    }
    const rec = AHOY.get().donations[0];
    document.getElementById("form-slot").innerHTML = `
      <div class="receipt">
        <div class="kicker" style="color:var(--gold-600)">Gift recorded</div>
        <h3 style="margin:6px 0 10px">Thank you${name ? ", " + name : ""}.</h3>
        <p>Reference <b class="mono">${rec.id}</b><br>
        ${UI.money2(amount)} toward <em>${camp.title}</em><br>
        Method: ${labelOf(method)} · ${rec.date}</p>
        <p class="muted mb0">A steward can see this in the admin ledger. In a live deployment this is where Stripe / Paystack / PayPal would confirm the charge.</p>
      </div>
      <button class="btn btn-ghost-ink mt" id="again" style="width:100%">Give again</button>`;
    document.getElementById("again").onclick = paint;
    // refresh the top numbers
    camp = AHOY.campaign(id);
    const p = UI.pct(camp.raised, camp.goal);
    const meta = document.querySelector(".pledge .fund-meta");
    const bar = document.querySelector(".pledge .progress > span");
    if (meta) meta.innerHTML = `<b>${UI.money(camp.raised)}</b><span>raised of ${UI.money(camp.goal)}</span>`;
    if (bar) bar.style.width = p + "%";
    UI.toast("Progress bar updated.");
  }

  paint();
});
