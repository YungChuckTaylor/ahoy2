/* Persistence layer. Seed once, then read/write localStorage. */
(function () {
  const KEY = "ahoy.v1";

  function clone(v) {
    return JSON.parse(JSON.stringify(v));
  }

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && parsed.items && parsed.campaigns) return parsed;
      }
    } catch (e) { /* ignore corrupt */ }
    const seed = clone(window.AHOY_SEED);
    seed.donations = seed.donations || [];
    seed.activity = [
      { at: new Date().toISOString(), actor: "system", action: "Archive seeded with verified records." }
    ];
    save(seed);
    return seed;
  }

  function save(state) {
    localStorage.setItem(KEY, JSON.stringify(state));
    window.dispatchEvent(new CustomEvent("ahoy:change", { detail: state }));
  }

  function get() { return load(); }

  function update(mutator) {
    const state = load();
    mutator(state);
    save(state);
    return state;
  }

  function reset() {
    localStorage.removeItem(KEY);
    return load();
  }

  /* --- queries --- */
  function items(filters) {
    let list = load().items.slice();
    if (!filters) return list;
    if (filters.category && filters.category !== "all") list = list.filter(i => i.category === filters.category);
    if (filters.country && filters.country !== "all") list = list.filter(i => i.country === filters.country);
    if (filters.verified === true) list = list.filter(i => i.verified);
    if (filters.q) {
      const q = filters.q.toLowerCase();
      list = list.filter(i =>
        (i.title + i.summary + i.id + i.body).toLowerCase().includes(q)
      );
    }
    list.sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    return list;
  }

  function item(id) { return load().items.find(i => i.id === id); }

  function campaigns() { return load().campaigns.slice(); }
  function campaign(id) { return load().campaigns.find(c => c.id === id); }

  function donate(payload) {
    return update(s => {
      const camp = s.campaigns.find(c => c.id === payload.campaign);
      if (!camp) throw new Error("Campaign not found");
      const amount = Number(payload.amount);
      if (!(amount > 0)) throw new Error("Invalid amount");
      camp.raised = Math.round((camp.raised + amount) * 100) / 100;
      const rec = {
        id: "don-" + Date.now(),
        campaign: payload.campaign,
        amount,
        method: payload.method,
        name: payload.public ? (payload.name || "Friend") : "Anonymous",
        date: new Date().toISOString().slice(0, 10),
        public: !!payload.public,
        note: payload.note || ""
      };
      s.donations.unshift(rec);
      s.activity.unshift({
        at: new Date().toISOString(),
        actor: "public",
        action: `Donation of $${amount} via ${payload.method} to ${camp.title}`
      });
    });
  }

  /* --- admin mutations --- */
  function upsertItem(rec) {
    return update(s => {
      const i = s.items.findIndex(x => x.id === rec.id);
      if (i >= 0) s.items[i] = rec;
      else s.items.unshift(rec);
      s.activity.unshift({ at: new Date().toISOString(), actor: "steward", action: `Saved archive item ${rec.id}` });
    });
  }

  function deleteItem(id) {
    return update(s => {
      s.items = s.items.filter(x => x.id !== id);
      s.activity.unshift({ at: new Date().toISOString(), actor: "steward", action: `Removed archive item ${id}` });
    });
  }

  function upsertCampaign(rec) {
    return update(s => {
      const i = s.campaigns.findIndex(x => x.id === rec.id);
      if (i >= 0) s.campaigns[i] = rec;
      else s.campaigns.unshift(rec);
      s.activity.unshift({ at: new Date().toISOString(), actor: "steward", action: `Saved campaign ${rec.id}` });
    });
  }

  function deleteCampaign(id) {
    return update(s => {
      s.campaigns = s.campaigns.filter(x => x.id !== id);
      s.activity.unshift({ at: new Date().toISOString(), actor: "steward", action: `Removed campaign ${id}` });
    });
  }

  function setHeadline(headline) {
    return update(s => {
      s.finances.headline = headline;
      s.activity.unshift({ at: new Date().toISOString(), actor: "steward", action: "Updated headline allocation" });
    });
  }

  function addReport(rec) {
    return update(s => {
      s.reports.unshift(rec);
      s.activity.unshift({ at: new Date().toISOString(), actor: "steward", action: `Published report ${rec.title}` });
    });
  }

  function deleteReport(id) {
    return update(s => {
      s.reports = s.reports.filter(r => r.id !== id);
    });
  }

  const SESSION = "ahoy.session";

  function login(email, password) {
    const admin = load().admin || window.AHOY_SEED.admin;
    const okEmail = email.trim().toLowerCase() === admin.email.toLowerCase();
    const okPass = password === admin.passwordPlainForDemo;
    if (!okEmail || !okPass) return { ok: false, error: "Those credentials were not recognised." };
    const token = { email: admin.email, at: Date.now(), exp: Date.now() + 1000 * 60 * 60 * 8 };
    sessionStorage.setItem(SESSION, JSON.stringify(token));
    update(s => s.activity.unshift({ at: new Date().toISOString(), actor: "steward", action: "Steward signed in" }));
    return { ok: true };
  }

  function logout() {
    sessionStorage.removeItem(SESSION);
  }

  function session() {
    try {
      const t = JSON.parse(sessionStorage.getItem(SESSION) || "null");
      if (!t || t.exp < Date.now()) { sessionStorage.removeItem(SESSION); return null; }
      return t;
    } catch (e) { return null; }
  }

  window.AHOY = {
    get, update, reset, items, item, campaigns, campaign, donate,
    upsertItem, deleteItem, upsertCampaign, deleteCampaign,
    setHeadline, addReport, deleteReport, login, logout, session,
    countries: () => window.AHOY_SEED.countries,
    categories: () => window.AHOY_SEED.categories
  };
})();
